Create one horizontal animation strip for ChatGPT pet `nori`, state `running-left`.

Use the attached canonical base for identity. Use the attached layout guide only for slot count, spacing, centering, and padding; do not draw the guide.

Output exactly 8 full-body frames in one left-to-right row on flat pure magenta #FF00FF. Treat the row as 8 invisible equal-width slots: one centered complete pose per slot, evenly spaced, with no overlap, clipping, empty slots, labels, or borders.

Identity: same pet in every frame: Clearly adult anime woman age 28, mature facial anatomy, small head relative to height, slender healthy adult physique, realistic six-and-half-to-seven-head body proportions, long legs, defined waist, naturally proportioned shoulders and hips, no chibi or childlike features. Teal bob haircut, golden eyes, cream fitted hoodie reaching high hip, opaque matte nude beige short leggings bike shorts to mid-thigh with clearly visible seams waistband and hems, cream sneakers. Neutral nonsexual full-body standing posture, hands at sides. Clean anime cel shading with sharp outlines, no props or asymmetric markings. Head physically yaws and pitches naturally to look around while torso and feet anchored.. Preserve silhouette, face, proportions, markings, palette, material, style, and props.
Style: Pet-safe sprite: compact full-body mascot, readable in a 192x208 cell, clear silhouette, simple face, stable palette/materials, and crisp edges for chroma-key extraction. Style `sticker`: Polished sticker mascot with bold clean shapes, crisp outline, flat colors, and minimal highlight detail.
Animation continuity: keep apparent pet scale and baseline stable within the row unless the state itself intentionally changes vertical position, such as `jumping`. Move the pose within the slot instead of redrawing the pet larger or smaller frame to frame.

State action: Dragging-left loop: show directional movement to the left through body and limb poses only.

State requirements:
- Show directional drag movement to the left through body, limb, and prop movement only.
- The row must unmistakably face and travel left.
- The movement cadence must alternate visibly across the 8 frames instead of repeating one nearly static stride.
- Do not draw speed lines, dust clouds, floor shadows, motion trails, or detached motion effects.

Clean extraction: crisp opaque edges, safe padding, no scenery, text, guide marks, checkerboard, shadows, glows, motion blur, speed lines, dust, detached effects, stray pixels, or chroma-key colors inside the pet.
